---
name: coin-ta
description: Use when the user asks for full technical analysis of a specific coin — orchestrates market-structure, support-resistance, range-trading, funding/basis and order-book skills into one chained verdict.
author: Oh My Binance contributors
license: MIT
metadata:
  hermes:
    tags: [crypto, ta, orchestrator, binance-agent-os]
---

# Coin TA (orchestrator)

Full technical workup on one symbol by chaining the atomic TA skills — visibly, in order, then synthesizing once.

## Skill chain (run in this order)
1. `market-structure` → trend/range state across 1D/4H, swing map, any structural break.
2. `support-resistance` → clustered pivot levels from ≥120 4H bars.
3. `range-trading` → if a valid range exists: boundaries, position, internal bias, MSB trigger status, plan math. If no range: skip and say trend regime.
4. `funding-analysis` + perp basis → who is paying, crowding direction.
5. `orderbook-analysis` → do live walls confirm/refute the mapped levels?

## Output
`COIN TA — <SYMBOL>`
- **PIPELINE** — one line listing which skills ran and what each returned (the chain, visible)
- **STRUCTURE** — regime + key swings (from 1)
- **LEVELS** — nearest support/resistance clusters (from 2)
- **RANGE/MSB** — range state + trigger status, or trend note (from 3)
- **POSITIONING** — funding + basis read (from 4)
- **BOOK** — wall confirmations (from 5)
- **VERDICT** — synthesized read: where price sits, what confirms, what invalidates. All gates named.
- End `Not financial advice.` + `CONFIDENCE: high|medium|low` + driver.

## Rules
- Each section must carry the numbers its source skill produced — no re-derivation.
- If a chain step's data is unavailable, silently omit that section.
- Contradictions between skills are the feature: surface them (e.g. structure bullish, funding crowded-long).
- No BUY/SELL output. Verdict = state + gates, never an instruction.

## Binance Agent OS data policy

Binance Agent OS is the **canonical data backend** for this library.
- Use the connected Binance Agent OS capabilities for crypto data.
- Do not replace Binance with another exchange or data provider.
- The skills are runtime/model agnostic; Binance Agent OS remains the data source.
- Prefer capability discovery over hardcoding a particular tool/function name.
- Preserve Binance-native timestamps and venue/market type flags.
- If Agent OS does not expose a required field, record it in the internal evidence layer only — per the Missing Data Silence Rule, never surface it in user-facing output.
- Never fabricate a value or silently substitute an unrelated metric.
